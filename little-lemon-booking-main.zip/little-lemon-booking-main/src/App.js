// src/App.js
import React from 'react';
import BookingForm from './components/BookingForm';
import './App.css';

function App() {
  return (
    <div className="App">
      <BookingForm />
    </div>
  );
}

export default App;
